import { useState, useEffect } from 'react';
import { CalculatorForm } from './components/CalculatorForm';
import { BillResult } from './components/BillResult';
import { CalculationResult } from './types';
import { formatVND } from './utils/format';
import { getSavedRooms, saveRoomProfile, normalizeRoomId } from './utils/storage';
import { Calculator, History, Trash2, Home, Receipt } from 'lucide-react';

const STORAGE_KEY = 'tinh_tien_tro_history_v1';

export default function App() {
  const [currentResult, setCurrentResult] = useState<CalculationResult | null>(null);
  const [history, setHistory] = useState<CalculationResult[]>([]);
  const [formKey, setFormKey] = useState<number>(0);

  // Load history from localStorage on first render
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        setHistory(JSON.parse(saved));
      }
    } catch {
      // Ignore storage read error
    }
  }, []);

  const handleCalculate = (result: CalculationResult) => {
    setCurrentResult(result);
    // Add to history (keep latest 5)
    setHistory(prev => {
      const updated = [result, ...prev.filter(item => item.calculatedAt !== result.calculatedAt)].slice(0, 5);
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      } catch {
        // Ignore storage write error
      }
      return updated;
    });

    // Scroll to bill on mobile if needed
    if (window.innerWidth < 1024) {
      setTimeout(() => {
        const el = document.getElementById('bill-result-card');
        if (el) {
          el.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
    }
  };

  const handleReset = () => {
    setCurrentResult(null);
  };

  const handleRolloverElectricity = (newElect: number, roomName: string) => {
    const rooms = getSavedRooms();
    const cleanRoomName = roomName || 'Phòng 101';
    const targetRoom = rooms.find(
      r => r.roomName.trim().toLowerCase() === cleanRoomName.trim().toLowerCase()
    );

    if (targetRoom) {
      saveRoomProfile({
        ...targetRoom,
        oldElectricity: newElect.toString(),
      });
    } else {
      saveRoomProfile({
        id: normalizeRoomId(cleanRoomName),
        roomName: cleanRoomName,
        oldElectricity: newElect.toString(),
        occupants: '1',
        roomRent: '2000000',
      });
    }

    // Refresh form with new oldElectricity
    setFormKey(k => k + 1);
  };

  const handleSelectFromHistory = (item: CalculationResult) => {
    setCurrentResult(item);
  };

  const handleClearHistory = () => {
    setHistory([]);
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      // Ignore
    }
  };

  return (
    <div className="min-h-screen bg-neutral-100 text-neutral-900 font-sans antialiased flex flex-col">
      {/* Top Header */}
      <header className="bg-white border-b border-neutral-200 sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-3.5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-sm">
              <Home className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-lg font-extrabold text-neutral-900 tracking-tight flex items-center gap-2">
                <span>Tính Tiền Trọ</span>
                <span className="text-[10px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                  Tiện Lợi
                </span>
              </h1>
              <p className="text-xs text-neutral-500">
                Tính tự động tiền điện, nước, rác và tổng tiền phòng trọ
              </p>
            </div>
          </div>

          <div className="hidden sm:flex items-center gap-4 text-xs text-neutral-500">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-amber-500"></span>
              <span>Điện 3.500 đ/số</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-sky-500"></span>
              <span>Nước 20.000 đ/người</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              <span>Rác 20.000 đ/phòng</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-6xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Column: Form Input (7 cols on desktop) */}
          <div className="lg:col-span-7 space-y-6">
            <CalculatorForm key={formKey} onCalculate={handleCalculate} onReset={handleReset} />

            {/* Quick History Card */}
            {history.length > 0 && (
              <div className="bg-white rounded-2xl border border-neutral-200 p-4 shadow-sm">
                <div className="flex items-center justify-between pb-2.5 mb-2.5 border-b border-neutral-100">
                  <span className="text-xs font-bold uppercase tracking-wider text-neutral-500 flex items-center gap-1.5">
                    <History className="w-3.5 h-3.5" />
                    Lịch sử tính gần đây
                  </span>
                  <button
                    type="button"
                    onClick={handleClearHistory}
                    className="text-[11px] text-neutral-400 hover:text-rose-600 flex items-center gap-1 transition-colors"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>Xóa lịch sử</span>
                  </button>
                </div>

                <div className="space-y-1.5">
                  {history.map((item, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleSelectFromHistory(item)}
                      className="w-full text-left flex items-center justify-between p-2.5 rounded-xl hover:bg-neutral-50 transition-colors border border-transparent hover:border-neutral-200 group"
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-700 flex items-center justify-center font-bold text-xs">
                          {item.roomName ? item.roomName.substring(0, 3) : `#${idx + 1}`}
                        </div>
                        <div>
                          <div className="text-xs font-semibold text-neutral-800">
                            {item.roomName ? `Phòng ${item.roomName}` : `Lần tính #${idx + 1}`}
                            <span className="text-neutral-400 font-normal ml-1.5 text-[11px]">
                              ({item.occupants} người &bull; {item.electricityUsed} số điện)
                            </span>
                          </div>
                          <div className="text-[10px] text-neutral-400">{item.calculatedAt}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="text-xs font-bold font-mono text-emerald-700 block">
                          {formatVND(item.grandTotal)}
                        </span>
                        <span className="text-[10px] text-indigo-600 opacity-0 group-hover:opacity-100 transition-opacity">
                          Xem lại &rarr;
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right Column: Bill Result (5 cols on desktop) */}
          <div className="lg:col-span-5 sticky top-20">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-neutral-500 flex items-center gap-1.5">
                <Receipt className="w-4 h-4" />
                Kết quả hóa đơn
              </span>
              {currentResult && (
                <span className="text-[11px] text-neutral-400">
                  Đã tính thành công
                </span>
              )}
            </div>

            <BillResult
              result={currentResult}
              onRolloverElectricity={handleRolloverElectricity}
            />
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-neutral-200 bg-white py-4 text-center text-xs text-neutral-400">
        <div className="max-w-6xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>Phần mềm tính tiền phòng trọ đơn giản và chuẩn xác</span>
          <div className="flex items-center gap-4 text-[11px]">
            <span>⚡ Điện: 3.500 đ/số</span>
            <span>💧 Nước: 20.000 đ/người</span>
            <span>🗑️ Rác: 20.000 đ/phòng</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
