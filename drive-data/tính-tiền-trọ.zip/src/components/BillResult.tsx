import React, { useState, useRef } from 'react';
import { CalculationResult } from '../types';
import { formatVND, generateBillShareText } from '../utils/format';
import {
  Zap,
  Droplets,
  Trash2,
  Home,
  Copy,
  Check,
  Printer,
  Calculator,
  Download,
  Loader2,
} from 'lucide-react';
import { toPng } from 'html-to-image';

interface BillResultProps {
  result: CalculationResult | null;
  onRolloverElectricity?: (newElectricity: number, roomName: string) => void;
}

export const BillResult: React.FC<BillResultProps> = ({ result }) => {
  const [copied, setCopied] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloaded, setDownloaded] = useState(false);
  const billCardRef = useRef<HTMLDivElement>(null);

  if (!result) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-8 bg-neutral-50/80 rounded-2xl border border-dashed border-neutral-200 text-center">
        <div className="w-14 h-14 rounded-2xl bg-neutral-100 flex items-center justify-center text-neutral-400 mb-3">
          <Calculator className="w-7 h-7" />
        </div>
        <h3 className="text-base font-semibold text-neutral-800">Chưa có kết quả tính tiền</h3>
        <p className="text-sm text-neutral-500 max-w-xs mt-1">
          Điền các thông tin số điện, số người và tiền phòng ở bên cạnh, sau đó nhấn &ldquo;Tính tiền&rdquo;.
        </p>
      </div>
    );
  }

  const handleCopy = async () => {
    try {
      const text = generateBillShareText(result);
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // Fallback if clipboard API fails
      setCopied(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadImage = async () => {
    if (!billCardRef.current || isDownloading) return;

    try {
      setIsDownloading(true);

      // Brief delay to ensure DOM styles are settled
      await new Promise((resolve) => setTimeout(resolve, 80));

      const dataUrl = await toPng(billCardRef.current, {
        cacheBust: true,
        pixelRatio: 2, // 2x scale for sharp text and crisp icons
        backgroundColor: '#ffffff',
        filter: (node) => {
          // Filter out action buttons and system alerts from the generated image
          if (node instanceof HTMLElement && node.classList.contains('no-export')) {
            return false;
          }
          return true;
        },
      });

      const safeRoom = result.roomName
        ? result.roomName.trim().replace(/[\s/\\:]+/g, '_')
        : 'Phong_tro';
      const safeDate = new Date().toISOString().slice(0, 10);
      const fileName = `Hoa_don_${safeRoom}_${safeDate}.png`;

      const downloadLink = document.createElement('a');
      downloadLink.download = fileName;
      downloadLink.href = dataUrl;
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);

      setDownloaded(true);
      setTimeout(() => setDownloaded(false), 3000);
    } catch (error) {
      console.error('Lỗi khi tải ảnh hóa đơn:', error);
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div
      ref={billCardRef}
      id="bill-result-card"
      className="bg-white rounded-2xl border border-neutral-200 shadow-sm overflow-hidden transition-all"
    >
      {/* Bill Header */}
      <div className="p-5 border-b border-neutral-100 bg-neutral-900 text-white flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-400"></span>
            <span className="text-xs tracking-wider uppercase font-semibold text-neutral-400">
              {result.roomName ? `Phòng: ${result.roomName}` : 'Hóa Đơn Tiền Trọ'}
            </span>
          </div>
          <h2 className="text-xl font-bold tracking-tight mt-0.5 text-white">
            {result.monthYear ? `Tiền trọ kỳ ${result.monthYear}` : 'Chi tiết thanh toán'}
          </h2>
        </div>
        <div className="text-right">
          <span className="text-xs text-neutral-400 block">Ngày lập</span>
          <span className="text-xs font-mono text-neutral-300">{result.calculatedAt}</span>
        </div>
      </div>

      {/* Bill Items */}
      <div className="p-6 space-y-4">
        {/* 1. Tiền Điện */}
        <div className="flex items-start justify-between p-3.5 rounded-xl bg-amber-50/50 border border-amber-100">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-amber-100 text-amber-700 mt-0.5">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <div className="font-semibold text-neutral-900 flex items-center gap-2">
                <span>Tiền điện</span>
                <span className="text-xs bg-amber-200/70 text-amber-900 px-2 py-0.5 rounded-full font-medium">
                  3.500 đ/số
                </span>
              </div>
              <div className="text-xs text-neutral-600 mt-1 space-y-0.5">
                <div>
                  Số mới: <span className="font-semibold text-neutral-800">{result.newElectricity}</span> &minus; Số cũ:{' '}
                  <span className="font-semibold text-neutral-800">{result.oldElectricity}</span>
                </div>
                <div className="text-amber-800 font-medium">
                  Tiêu thụ: {result.electricityUsed} kWh &times; 3.500 đ
                </div>
              </div>
            </div>
          </div>
          <div className="text-right">
            <span className="text-base font-bold text-neutral-900 font-mono">
              {formatVND(result.electricityTotal)}
            </span>
          </div>
        </div>

        {/* 2. Tiền Nước */}
        <div className="flex items-start justify-between p-3.5 rounded-xl bg-sky-50/50 border border-sky-100">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-sky-100 text-sky-700 mt-0.5">
              <Droplets className="w-5 h-5" />
            </div>
            <div>
              <div className="font-semibold text-neutral-900 flex items-center gap-2">
                <span>Tiền nước</span>
                <span className="text-xs bg-sky-200/70 text-sky-900 px-2 py-0.5 rounded-full font-medium">
                  20.000 đ/người
                </span>
              </div>
              <div className="text-xs text-neutral-600 mt-1">
                Số người: <span className="font-semibold text-neutral-800">{result.occupants}</span> người &times; 20.000 đ
              </div>
            </div>
          </div>
          <div className="text-right">
            <span className="text-base font-bold text-neutral-900 font-mono">
              {formatVND(result.waterTotal)}
            </span>
          </div>
        </div>

        {/* 3. Tiền Rác */}
        <div className="flex items-start justify-between p-3.5 rounded-xl bg-emerald-50/50 border border-emerald-100">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-emerald-100 text-emerald-700 mt-0.5">
              <Trash2 className="w-5 h-5" />
            </div>
            <div>
              <div className="font-semibold text-neutral-900 flex items-center gap-2">
                <span>Tiền rác</span>
                <span className="text-xs bg-emerald-200/70 text-emerald-900 px-2 py-0.5 rounded-full font-medium">
                  Cố định
                </span>
              </div>
              <div className="text-xs text-neutral-600 mt-1">
                Quy định 20.000 đ / 1 phòng
              </div>
            </div>
          </div>
          <div className="text-right">
            <span className="text-base font-bold text-neutral-900 font-mono">
              {formatVND(result.garbageTotal)}
            </span>
          </div>
        </div>

        {/* 4. Tiền Trọ */}
        <div className="flex items-start justify-between p-3.5 rounded-xl bg-indigo-50/50 border border-indigo-100">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-indigo-100 text-indigo-700 mt-0.5">
              <Home className="w-5 h-5" />
            </div>
            <div>
              <div className="font-semibold text-neutral-900">Tiền trọ / phòng</div>
              <div className="text-xs text-neutral-600 mt-1">
                Giá thuê niêm yết theo tháng
              </div>
            </div>
          </div>
          <div className="text-right">
            <span className="text-base font-bold text-neutral-900 font-mono">
              {formatVND(result.roomRent)}
            </span>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-dashed border-neutral-200 pt-3"></div>

        {/* Grand Total */}
        <div className="p-4 rounded-xl bg-gradient-to-br from-neutral-900 to-neutral-800 text-white shadow-md flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
              Tổng tiền cần thanh toán
            </span>
            <div className="text-xs text-neutral-300 mt-0.5">
              (Điện + Nước + Rác + Tiền trọ)
            </div>
          </div>
          <div className="text-right">
            <div className="text-2xl sm:text-3xl font-extrabold text-emerald-400 font-mono tracking-tight">
              {formatVND(result.grandTotal)}
            </div>
          </div>
        </div>

        {/* Auto Rollover status notice */}
        <div className="no-export p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-center gap-2.5">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></div>
          <div>
            <span className="font-semibold">Đã lưu trữ số điện cho tháng sau:</span>{' '}
            Số mới <span className="font-mono font-bold text-emerald-800">{result.newElectricity}</span> đã tự động chuyển thành <strong>số điện cũ</strong> của {result.roomName || 'phòng'}.
          </div>
        </div>

        {/* Nút Tải hình ảnh (nằm trên Sao chép hóa đơn và In hóa đơn) */}
        <div className="no-export pt-1">
          <button
            id="download-image-button"
            type="button"
            onClick={handleDownloadImage}
            disabled={isDownloading}
            className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white text-sm font-semibold transition-all shadow-sm active:scale-[0.98] disabled:opacity-75 cursor-pointer"
          >
            {isDownloading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Đang tạo hình ảnh hóa đơn...</span>
              </>
            ) : downloaded ? (
              <>
                <Check className="w-4 h-4 text-emerald-300" />
                <span className="text-emerald-100">Đã tải hình ảnh về máy!</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>Tải hình ảnh hóa đơn</span>
              </>
            )}
          </button>
        </div>

        {/* Actions: Sao chép hóa đơn & In hóa đơn */}
        <div className="no-export grid grid-cols-2 gap-3 pt-1">
          <button
            id="copy-bill-button"
            type="button"
            onClick={handleCopy}
            className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl border border-neutral-300 bg-white hover:bg-neutral-50 text-neutral-800 text-sm font-semibold transition-all shadow-sm active:scale-[0.98]"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-emerald-600" />
                <span className="text-emerald-700">Đã sao chép!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4 text-neutral-600" />
                <span>Sao chép hóa đơn</span>
              </>
            )}
          </button>

          <button
            id="print-bill-button"
            type="button"
            onClick={handlePrint}
            className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl border border-neutral-300 bg-white hover:bg-neutral-50 text-neutral-800 text-sm font-semibold transition-all shadow-sm active:scale-[0.98]"
          >
            <Printer className="w-4 h-4 text-neutral-600" />
            <span>In hóa đơn</span>
          </button>
        </div>

        {/* Subtle note about the formula */}
        <div className="text-center text-[11px] text-neutral-400 pt-1">
          * Đơn giá: Điện 3.500 đ/số &bull; Nước 20.000 đ/người &bull; Rác 20.000 đ/phòng
        </div>
      </div>
    </div>
  );
};
