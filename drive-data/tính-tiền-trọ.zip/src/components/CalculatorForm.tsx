import React, { useState, useEffect, useRef } from 'react';
import { CalculationInput, CalculationResult, RoomProfile } from '../types';
import {
  Zap,
  Users,
  Home,
  Calculator,
  RotateCcw,
  AlertCircle,
  Info,
  Save,
  Check,
  Plus,
  Trash2,
  BookmarkCheck,
  CheckCircle2,
} from 'lucide-react';
import {
  getSavedRooms,
  saveRoomProfile,
  deleteRoomProfile,
  getActiveRoomId,
  setActiveRoomId,
  saveLastFormState,
  normalizeRoomId,
} from '../utils/storage';

interface CalculatorFormProps {
  onCalculate: (result: CalculationResult) => void;
  onReset: () => void;
  currentRoomId?: string;
  onRoomSelect?: (roomId: string) => void;
}

export const CalculatorForm: React.FC<CalculatorFormProps> = ({
  onCalculate,
  onReset,
}) => {
  const [rooms, setRooms] = useState<RoomProfile[]>([]);
  const [activeRoomId, setActiveRoomIdState] = useState<string>('');
  const [saveStatus, setSaveStatus] = useState<string | null>(null);
  const [isAddingRoom, setIsAddingRoom] = useState<boolean>(false);
  const [newRoomNameInput, setNewRoomNameInput] = useState<string>('');

  const [formData, setFormData] = useState<CalculationInput>({
    roomName: 'Phòng 101',
    monthYear: new Date().toLocaleDateString('vi-VN', { month: '2-digit', year: 'numeric' }),
    oldElectricity: '1240',
    newElectricity: '',
    thisMonthElectricity: '',
    occupants: '2',
    roomRent: '2500000',
  });

  const [error, setError] = useState<string | null>(null);
  const [rolloverNotice, setRolloverNotice] = useState<{
    roomName: string;
    previousOld: number;
    newAsOld: number;
  } | null>(null);
  const saveTimeoutRef = useRef<number | null>(null);

  // Initialize rooms and load active room on mount
  useEffect(() => {
    const loadedRooms = getSavedRooms();
    setRooms(loadedRooms);

    const savedActiveId = getActiveRoomId();
    const targetRoom = loadedRooms.find(r => r.id === savedActiveId) || loadedRooms[0];

    if (targetRoom) {
      setActiveRoomIdState(targetRoom.id);
      setFormData(prev => ({
        ...prev,
        roomName: targetRoom.roomName,
        oldElectricity: targetRoom.oldElectricity || '',
        occupants: targetRoom.occupants || '1',
        roomRent: targetRoom.roomRent || '2000000',
        newElectricity: '',
        thisMonthElectricity: '',
      }));
    }
  }, []);

  // Helper to persist current room's data to localStorage
  const autoSaveCurrentRoom = (updatedForm: CalculationInput, roomId?: string) => {
    const targetId = roomId || activeRoomId || normalizeRoomId(updatedForm.roomName || 'phong-moi');
    const profile: RoomProfile = {
      id: targetId,
      roomName: updatedForm.roomName || 'Phòng mới',
      oldElectricity: updatedForm.oldElectricity,
      occupants: updatedForm.occupants,
      roomRent: updatedForm.roomRent,
    };

    const newRoomsList = saveRoomProfile(profile);
    setRooms(newRoomsList);
    setActiveRoomId(targetId);
    saveLastFormState(updatedForm);

    setSaveStatus('Đã lưu vào bộ nhớ');
    if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
    saveTimeoutRef.current = window.setTimeout(() => {
      setSaveStatus(null);
    }, 2000);
  };

  // Switch Room
  const handleSelectRoom = (room: RoomProfile) => {
    setActiveRoomIdState(room.id);
    setActiveRoomId(room.id);

    const newForm: CalculationInput = {
      ...formData,
      roomName: room.roomName,
      oldElectricity: room.oldElectricity,
      occupants: room.occupants,
      roomRent: room.roomRent,
      newElectricity: '',
      thisMonthElectricity: '',
    };

    setFormData(newForm);
    saveLastFormState(newForm);
    setError(null);
    setRolloverNotice(null);
  };

  // Add new room
  const handleAddNewRoom = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const trimmed = newRoomNameInput.trim();
    if (!trimmed) return;

    const newId = normalizeRoomId(trimmed) || `room-${Date.now()}`;
    const newProfile: RoomProfile = {
      id: newId,
      roomName: trimmed,
      oldElectricity: '0',
      occupants: '1',
      roomRent: '2000000',
    };

    const updated = saveRoomProfile(newProfile);
    setRooms(updated);
    setActiveRoomIdState(newId);
    setActiveRoomId(newId);

    const newForm: CalculationInput = {
      ...formData,
      roomName: trimmed,
      oldElectricity: '0',
      occupants: '1',
      roomRent: '2000000',
      newElectricity: '',
      thisMonthElectricity: '',
    };
    setFormData(newForm);
    saveLastFormState(newForm);

    setNewRoomNameInput('');
    setIsAddingRoom(false);
    setSaveStatus(`Đã tạo ${trimmed}`);
    setTimeout(() => setSaveStatus(null), 2500);
  };

  // Delete current room
  const handleDeleteRoom = (roomId: string, roomName: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (rooms.length <= 1) {
      alert('Bạn cần giữ lại ít nhất 1 phòng.');
      return;
    }
    const confirmDelete = window.confirm(`Bạn có chắc muốn xóa "${roomName}" khỏi danh sách lưu trữ?`);
    if (!confirmDelete) return;

    const remaining = deleteRoomProfile(roomId);
    setRooms(remaining);

    if (activeRoomId === roomId && remaining.length > 0) {
      handleSelectRoom(remaining[0]);
    }
  };

  // Synchronize Old, New, and This Month Electricity
  const handleOldElectricityChange = (val: string) => {
    const oldNum = parseFloat(val);
    const newNum = parseFloat(formData.newElectricity);

    let thisMonth = formData.thisMonthElectricity;
    if (!isNaN(oldNum) && !isNaN(newNum)) {
      thisMonth = (newNum - oldNum >= 0 ? newNum - oldNum : 0).toString();
    }

    const updated = {
      ...formData,
      oldElectricity: val,
      thisMonthElectricity: thisMonth,
    };
    setFormData(updated);
    setError(null);
    autoSaveCurrentRoom(updated);
  };

  const handleNewElectricityChange = (val: string) => {
    const newNum = parseFloat(val);
    const oldNum = parseFloat(formData.oldElectricity);

    let thisMonth = formData.thisMonthElectricity;
    if (!isNaN(oldNum) && !isNaN(newNum)) {
      thisMonth = (newNum - oldNum >= 0 ? newNum - oldNum : 0).toString();
    }

    const updated = {
      ...formData,
      newElectricity: val,
      thisMonthElectricity: thisMonth,
    };
    setFormData(updated);
    setError(null);
    saveLastFormState(updated);
  };

  // If user enters 'thisMonthElectricity' directly (số điện tiêu thụ trong tháng)
  const handleThisMonthElectricityChange = (val: string) => {
    const usedNum = parseFloat(val);
    const oldNum = parseFloat(formData.oldElectricity);

    let newNumStr = formData.newElectricity;
    if (!isNaN(usedNum) && !isNaN(oldNum)) {
      newNumStr = (oldNum + usedNum).toString();
    }

    const updated = {
      ...formData,
      thisMonthElectricity: val,
      newElectricity: newNumStr,
    };
    setFormData(updated);
    setError(null);
    saveLastFormState(updated);
  };

  const handleOccupantsChange = (val: string) => {
    const updated = { ...formData, occupants: val };
    setFormData(updated);
    setError(null);
    autoSaveCurrentRoom(updated);
  };

  const handleRoomRentChange = (val: string) => {
    const cleanVal = val.replace(/\D/g, '');
    const updated = { ...formData, roomRent: cleanVal };
    setFormData(updated);
    setError(null);
    autoSaveCurrentRoom(updated);
  };

  const handleRentPreset = (amount: number) => {
    const updated = { ...formData, roomRent: amount.toString() };
    setFormData(updated);
    autoSaveCurrentRoom(updated);
  };

  const handleRoomNameChange = (val: string) => {
    const updated = { ...formData, roomName: val };
    setFormData(updated);
    autoSaveCurrentRoom(updated);
  };

  const handleManualSave = () => {
    autoSaveCurrentRoom(formData);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const oldNum = parseFloat(formData.oldElectricity);
    const newNum = parseFloat(formData.newElectricity);
    const thisMonthNum = parseFloat(formData.thisMonthElectricity);
    const occupantsNum = parseInt(formData.occupants, 10);
    const roomRentNum = parseFloat(formData.roomRent);

    if (isNaN(oldNum) || oldNum < 0) {
      setError('Vui lòng nhập số điện cũ hợp lệ (≥ 0).');
      return;
    }

    let electricityUsed = 0;

    // Requirement:
    // "nhập sẽ gồm số điện cũ,số điện mới,số điện tháng này, số người ở,tiền trọ và nút tính tiền...
    // sau khi nhập tiền điện tháng này sẽ lấy số điện tháng này trừ số điện cũ sau đó nhân với 3.500 vnd mỗi số điện"
    if (!isNaN(newNum) && newNum >= oldNum) {
      electricityUsed = newNum - oldNum;
    } else if (!isNaN(thisMonthNum) && thisMonthNum >= oldNum) {
      // If "số điện tháng này" was entered as the current meter reading
      electricityUsed = thisMonthNum - oldNum;
    } else if (!isNaN(thisMonthNum) && thisMonthNum > 0) {
      // If "số điện tháng này" was entered as consumption difference
      electricityUsed = thisMonthNum;
    } else {
      setError('Số điện mới (hoặc số điện tháng này) phải lớn hơn hoặc bằng số điện cũ.');
      return;
    }

    if (isNaN(occupantsNum) || occupantsNum <= 0) {
      setError('Số người ở phải lớn hơn hoặc bằng 1.');
      return;
    }

    if (isNaN(roomRentNum) || roomRentNum < 0) {
      setError('Vui lòng nhập số tiền trọ hợp lệ.');
      return;
    }

    // Formulas:
    // Tiền điện = (Số điện tháng này - Số điện cũ) * 3.500
    // Tiền nước ẩn = 20.000 * số người
    // Tiền rác = 20.000 / phòng
    // Tiền trọ = tiền phòng đã nhập
    // Tổng = Tiền điện + Tiền nước + Tiền rác + Tiền trọ
    const electricityRate = 3500;
    const electricityTotal = electricityUsed * electricityRate;

    const waterRate = 20000;
    const waterTotal = occupantsNum * waterRate;

    const garbageTotal = 20000;
    const roomRent = roomRentNum;

    const grandTotal = electricityTotal + waterTotal + garbageTotal + roomRent;

    const now = new Date();
    const calculatedAt = `${now.getHours().toString().padStart(2, '0')}:${now
      .getMinutes()
      .toString()
      .padStart(2, '0')} - ${now.toLocaleDateString('vi-VN')}`;

    const calculatedNewElectricity = !isNaN(newNum) ? newNum : oldNum + electricityUsed;

    // 1. Hiển thị hóa đơn tháng này với số điện cũ và số điện mới
    onCalculate({
      roomName: formData.roomName?.trim() || '',
      monthYear: formData.monthYear?.trim() || '',
      oldElectricity: oldNum,
      newElectricity: calculatedNewElectricity,
      electricityUsed,
      electricityRate,
      electricityTotal,
      occupants: occupantsNum,
      waterRate,
      waterTotal,
      garbageTotal,
      roomRent,
      grandTotal,
      calculatedAt,
    });

    // 2. Chuyển số điện mới thành số điện cũ và lưu lại để tháng sau tính tiếp
    const nextMonthForm: CalculationInput = {
      ...formData,
      oldElectricity: calculatedNewElectricity.toString(),
      newElectricity: '',
      thisMonthElectricity: '',
    };
    setFormData(nextMonthForm);

    // Lưu ngay số điện cũ mới này và thông tin phòng vào localStorage
    autoSaveCurrentRoom(nextMonthForm);

    // Thông báo cho người dùng
    setRolloverNotice({
      roomName: formData.roomName?.trim() || 'Phòng này',
      previousOld: oldNum,
      newAsOld: calculatedNewElectricity,
    });
  };

  const handleResetForm = () => {
    setFormData(prev => ({
      ...prev,
      newElectricity: '',
      thisMonthElectricity: '',
    }));
    setError(null);
    setRolloverNotice(null);
    onReset();
  };

  return (
    <div className="bg-white rounded-2xl border border-neutral-200 shadow-sm p-5 sm:p-6">
      {/* Header & Storage Indicator */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 mb-4 border-b border-neutral-100 gap-2">
        <div>
          <h2 className="text-lg font-bold text-neutral-900 flex items-center gap-2">
            <Calculator className="w-5 h-5 text-indigo-600" />
            <span>Nhập thông tin tính tiền trọ</span>
          </h2>
          <p className="text-xs text-neutral-500 mt-0.5">
            Dữ liệu phòng (số điện cũ, tiền trọ, số người) tự động lưu trên máy khi tải lại trang
          </p>
        </div>

        <div className="flex items-center gap-2">
          {saveStatus ? (
            <span className="text-[11px] font-medium text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-lg flex items-center gap-1.5 transition-all animate-pulse">
              <Check className="w-3.5 h-3.5 text-emerald-600" />
              <span>{saveStatus}</span>
            </span>
          ) : (
            <button
              type="button"
              onClick={handleManualSave}
              className="text-[11px] font-medium text-neutral-600 hover:text-indigo-600 bg-neutral-100 hover:bg-neutral-200/80 px-2.5 py-1 rounded-lg flex items-center gap-1 transition-colors"
              title="Lưu số điện cũ, tiền trọ, số người của phòng này"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Lưu phòng</span>
            </button>
          )}
        </div>
      </div>

      {/* Room Selector Pills (Tabs for Rooms) */}
      <div className="mb-5 p-3 rounded-xl bg-neutral-50 border border-neutral-200/80">
        <div className="flex items-center justify-between mb-2">
          <label className="text-xs font-bold uppercase tracking-wider text-neutral-600 flex items-center gap-1.5">
            <BookmarkCheck className="w-4 h-4 text-indigo-600" />
            <span>Danh sách phòng đã lưu:</span>
          </label>
          <span className="text-[11px] text-neutral-400">Chọn phòng để nạp nhanh</span>
        </div>

        <div className="flex items-center gap-1.5 flex-wrap">
          {rooms.map(room => {
            const isSelected = room.id === activeRoomId;
            return (
              <div
                key={room.id}
                onClick={() => handleSelectRoom(room)}
                className={`group flex items-center gap-1.5 py-1.5 px-3 rounded-xl text-xs font-semibold cursor-pointer border transition-all ${
                  isSelected
                    ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                    : 'bg-white text-neutral-700 border-neutral-200 hover:border-indigo-300 hover:bg-indigo-50/50'
                }`}
              >
                <span>{room.roomName}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                    isSelected ? 'bg-indigo-500 text-white' : 'bg-neutral-100 text-neutral-500'
                  }`}
                >
                  {room.occupants} ng
                </span>
                {rooms.length > 1 && (
                  <button
                    type="button"
                    onClick={e => handleDeleteRoom(room.id, room.roomName, e)}
                    className={`ml-1 opacity-0 group-hover:opacity-100 hover:text-rose-500 p-0.5 rounded transition-opacity ${
                      isSelected ? 'text-indigo-200 hover:text-white' : 'text-neutral-400'
                    }`}
                    title="Xóa phòng này"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                )}
              </div>
            );
          })}

          {/* Add Room Button or Form */}
          {isAddingRoom ? (
            <form onSubmit={handleAddNewRoom} className="flex items-center gap-1">
              <input
                type="text"
                autoFocus
                placeholder="VD: Phòng 202"
                value={newRoomNameInput}
                onChange={e => setNewRoomNameInput(e.target.value)}
                className="px-2.5 py-1 text-xs rounded-lg border border-indigo-500 focus:outline-none bg-white text-neutral-900 w-28"
              />
              <button
                type="submit"
                className="px-2 py-1 bg-indigo-600 text-white rounded-lg text-xs font-semibold hover:bg-indigo-700"
              >
                Thêm
              </button>
              <button
                type="button"
                onClick={() => setIsAddingRoom(false)}
                className="px-2 py-1 bg-neutral-200 text-neutral-700 rounded-lg text-xs hover:bg-neutral-300"
              >
                Hủy
              </button>
            </form>
          ) : (
            <button
              type="button"
              onClick={() => setIsAddingRoom(true)}
              className="flex items-center gap-1 py-1.5 px-2.5 rounded-xl text-xs font-medium text-indigo-600 bg-white hover:bg-indigo-50 border border-dashed border-indigo-300 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Thêm phòng</span>
            </button>
          )}
        </div>
      </div>

      {error && (
        <div className="mb-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Room Name & Period */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-neutral-700 mb-1">
              Tên / Số phòng trọ <span className="text-rose-500">*</span>
            </label>
            <input
              id="input-room-name"
              type="text"
              required
              placeholder="VD: Phòng 101"
              value={formData.roomName}
              onChange={e => handleRoomNameChange(e.target.value)}
              className="w-full px-3 py-2 text-sm rounded-xl border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all font-medium"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-neutral-700 mb-1">
              Kỳ tính tiền
            </label>
            <input
              id="input-month-year"
              type="text"
              placeholder="Tháng 09/2026"
              value={formData.monthYear}
              onChange={e => setFormData({ ...formData, monthYear: e.target.value })}
              className="w-full px-3 py-2 text-sm rounded-xl border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-all"
            />
          </div>
        </div>

        {/* Electricity Section (Old, New, This Month) */}
        <div className="p-4 rounded-xl bg-amber-50/40 border border-amber-200/70 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-900 flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-amber-600" />
              Chỉ số điện (Đơn giá 3.500 đ/số)
            </span>
            <span className="text-[11px] font-semibold text-amber-800 bg-amber-100 px-2 py-0.5 rounded-full">
              ⚡ 3.500 đ/số
            </span>
          </div>

          {/* Rollover notice banner */}
          {rolloverNotice && (
            <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs flex items-start gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
              <div>
                <div className="font-bold text-emerald-800">
                  Đã chuyển số mới ({rolloverNotice.newAsOld}) thành số cũ cho tháng sau!
                </div>
                <div className="text-[11px] text-emerald-700 mt-0.5">
                  Số điện cũ của {rolloverNotice.roomName} đã được cập nhật thành{' '}
                  <span className="font-mono font-bold text-emerald-900">{rolloverNotice.newAsOld} kWh</span> và lưu trữ trong bộ nhớ. Tháng sau bạn chỉ cần nhập số điện mới vào ô bên cạnh!
                </div>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Số điện cũ */}
            <div>
              <label className="block text-xs font-semibold text-neutral-700 mb-1">
                1. Số điện cũ <span className="text-amber-700 font-normal">(đã lưu)</span>
              </label>
              <div className="relative">
                <input
                  id="input-old-electricity"
                  type="number"
                  min="0"
                  step="any"
                  required
                  placeholder="VD: 1200"
                  value={formData.oldElectricity}
                  onChange={e => handleOldElectricityChange(e.target.value)}
                  className="w-full px-3 py-2 pr-10 text-sm rounded-xl border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-600 font-mono font-medium"
                />
                <span className="absolute right-3 top-2.5 text-xs text-neutral-400 font-medium">kWh</span>
              </div>
            </div>

            {/* Số điện mới */}
            <div>
              <label className="block text-xs font-semibold text-neutral-700 mb-1">
                2. Số điện mới <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <input
                  id="input-new-electricity"
                  type="number"
                  min="0"
                  step="any"
                  placeholder="VD: 1350"
                  value={formData.newElectricity}
                  onChange={e => handleNewElectricityChange(e.target.value)}
                  className="w-full px-3 py-2 pr-10 text-sm rounded-xl border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-600 font-mono font-medium"
                />
                <span className="absolute right-3 top-2.5 text-xs text-neutral-400 font-medium">kWh</span>
              </div>
            </div>

            {/* Số điện tháng này (Số tiêu thụ) */}
            <div>
              <label className="block text-xs font-semibold text-neutral-700 mb-1">
                3. Số điện tháng này
              </label>
              <div className="relative">
                <input
                  id="input-this-month-electricity"
                  type="number"
                  min="0"
                  step="any"
                  placeholder="Mới - Cũ"
                  value={formData.thisMonthElectricity}
                  onChange={e => handleThisMonthElectricityChange(e.target.value)}
                  className="w-full px-3 py-2 pr-10 text-sm rounded-xl border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-amber-500/30 focus:border-amber-600 font-mono bg-amber-50/30"
                />
                <span className="absolute right-3 top-2.5 text-xs text-neutral-400 font-medium">kWh</span>
              </div>
            </div>
          </div>

          <div className="text-[11px] text-amber-800 flex items-center gap-1.5 pt-0.5">
            <Info className="w-3.5 h-3.5 flex-shrink-0" />
            <span>
              Công thức: (Số điện tháng này &minus; Số điện cũ) &times; 3.500 đ
            </span>
          </div>
        </div>

        {/* Occupants & Room Rent */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Số người ở */}
          <div>
            <label className="block text-xs font-semibold text-neutral-700 mb-1">
              Số người ở <span className="text-indigo-600 font-normal">(lưu theo phòng)</span>
            </label>
            <div className="relative">
              <input
                id="input-occupants"
                type="number"
                min="1"
                required
                placeholder="VD: 2"
                value={formData.occupants}
                onChange={e => handleOccupantsChange(e.target.value)}
                className="w-full px-3 py-2 pl-9 pr-14 text-sm rounded-xl border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 font-mono font-medium"
              />
              <Users className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
              <span className="absolute right-3 top-2.5 text-xs text-neutral-400 font-medium">người</span>
            </div>
            <p className="text-[11px] text-neutral-500 mt-1">
              Nước tự động tính: 20.000 đ &times; {formData.occupants || 1} người
            </p>
          </div>

          {/* Tiền trọ */}
          <div>
            <label className="block text-xs font-semibold text-neutral-700 mb-1">
              Tiền trọ / phòng <span className="text-indigo-600 font-normal">(lưu theo phòng)</span>
            </label>
            <div className="relative">
              <input
                id="input-room-rent"
                type="text"
                required
                placeholder="VD: 2.500.000"
                value={formData.roomRent ? Number(formData.roomRent).toLocaleString('vi-VN') : ''}
                onChange={e => handleRoomRentChange(e.target.value)}
                className="w-full px-3 py-2 pl-9 pr-10 text-sm rounded-xl border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 font-mono font-bold text-neutral-900"
              />
              <Home className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
              <span className="absolute right-3 top-2.5 text-xs text-neutral-400 font-medium">VNĐ</span>
            </div>

            {/* Quick Rent Presets */}
            <div className="flex items-center gap-1.5 mt-1.5 overflow-x-auto pb-0.5">
              {[1500000, 2000000, 2500000, 3000000].map(amt => (
                <button
                  key={amt}
                  type="button"
                  onClick={() => handleRentPreset(amt)}
                  className="text-[10px] font-medium px-2 py-0.5 rounded-md bg-neutral-100 hover:bg-neutral-200 text-neutral-600 transition-colors whitespace-nowrap"
                >
                  {(amt / 1000000).toLocaleString('vi-VN')}tr
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Preset Costs Info */}
        <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200 text-xs text-neutral-600 space-y-1">
          <div className="flex items-center justify-between text-neutral-700 font-medium">
            <span>Chi phí cố định quy định:</span>
            <span className="text-[11px] text-emerald-700 font-medium">✓ Đã kích hoạt</span>
          </div>
          <div className="grid grid-cols-2 gap-2 text-[11px] pt-1 text-neutral-500">
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-sky-500"></span>
              <span>Tiền nước: <strong>20.000 đ/người</strong> (ẩn ở bảng nhập)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
              <span>Tiền rác: <strong>20.000 đ/phòng</strong></span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="pt-2 flex items-center gap-3">
          <button
            id="calculate-button"
            type="submit"
            className="flex-1 flex items-center justify-center gap-2 py-3 px-6 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:scale-[0.99] text-white font-bold text-sm shadow-sm transition-all cursor-pointer"
          >
            <Calculator className="w-4 h-4" />
            <span>Tính tiền phòng</span>
          </button>

          <button
            id="reset-button"
            type="button"
            onClick={handleResetForm}
            className="p-3 rounded-xl border border-neutral-300 hover:bg-neutral-100 text-neutral-600 transition-colors"
            title="Làm mới form"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </form>
    </div>
  );
};
