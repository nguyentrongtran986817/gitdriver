export interface RoomProfile {
  id: string;
  roomName: string;
  oldElectricity: string;
  occupants: string;
  roomRent: string;
  lastUpdated?: string;
}

export interface CalculationInput {
  oldElectricity: string;
  newElectricity: string;
  thisMonthElectricity: string; // Số điện tiêu thụ / số điện tháng này
  occupants: string;
  roomRent: string;
  roomName?: string;
  monthYear?: string;
}

export interface CalculationResult {
  roomName: string;
  monthYear: string;
  oldElectricity: number;
  newElectricity: number;
  electricityUsed: number;
  electricityRate: number;
  electricityTotal: number;
  occupants: number;
  waterRate: number;
  waterTotal: number;
  garbageTotal: number;
  roomRent: number;
  grandTotal: number;
  calculatedAt: string;
}
