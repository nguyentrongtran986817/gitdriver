import { RoomProfile, CalculationInput } from '../types';

const ROOMS_KEY = 'tinh_tien_tro_rooms_v2';
const ACTIVE_ROOM_KEY = 'tinh_tien_tro_active_room_v2';
const LAST_FORM_KEY = 'tinh_tien_tro_last_form_v2';

const DEFAULT_ROOMS: RoomProfile[] = [
  {
    id: 'phong-101',
    roomName: 'Phòng 101',
    oldElectricity: '1240',
    occupants: '2',
    roomRent: '2500000',
    lastUpdated: 'Hệ thống mặc định',
  },
  {
    id: 'phong-102',
    roomName: 'Phòng 102',
    oldElectricity: '860',
    occupants: '1',
    roomRent: '2000000',
    lastUpdated: 'Hệ thống mặc định',
  },
  {
    id: 'phong-103',
    roomName: 'Phòng 103',
    oldElectricity: '2150',
    occupants: '3',
    roomRent: '3000000',
    lastUpdated: 'Hệ thống mặc định',
  },
];

export const normalizeRoomId = (name: string): string => {
  return name
    .trim()
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]/g, '-');
};

export const getSavedRooms = (): RoomProfile[] => {
  try {
    const raw = localStorage.getItem(ROOMS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch {
    // Fallback to defaults
  }
  // Initialize defaults into localStorage
  try {
    localStorage.setItem(ROOMS_KEY, JSON.stringify(DEFAULT_ROOMS));
  } catch {
    // Ignore
  }
  return DEFAULT_ROOMS;
};

export const saveRoomProfile = (profile: RoomProfile): RoomProfile[] => {
  try {
    const rooms = getSavedRooms();
    const existingIndex = rooms.findIndex(
      r => r.id === profile.id || r.roomName.trim().toLowerCase() === profile.roomName.trim().toLowerCase()
    );

    let updatedRooms: RoomProfile[];
    if (existingIndex >= 0) {
      updatedRooms = [...rooms];
      updatedRooms[existingIndex] = {
        ...updatedRooms[existingIndex],
        ...profile,
        lastUpdated: new Date().toLocaleDateString('vi-VN'),
      };
    } else {
      updatedRooms = [
        ...rooms,
        {
          ...profile,
          lastUpdated: new Date().toLocaleDateString('vi-VN'),
        },
      ];
    }

    localStorage.setItem(ROOMS_KEY, JSON.stringify(updatedRooms));
    return updatedRooms;
  } catch {
    return getSavedRooms();
  }
};

export const deleteRoomProfile = (id: string): RoomProfile[] => {
  try {
    const rooms = getSavedRooms();
    const updatedRooms = rooms.filter(r => r.id !== id);
    localStorage.setItem(ROOMS_KEY, JSON.stringify(updatedRooms));
    return updatedRooms;
  } catch {
    return getSavedRooms();
  }
};

export const getActiveRoomId = (): string => {
  try {
    const id = localStorage.getItem(ACTIVE_ROOM_KEY);
    if (id) return id;
  } catch {
    // Ignore
  }
  return 'phong-101';
};

export const setActiveRoomId = (id: string): void => {
  try {
    localStorage.setItem(ACTIVE_ROOM_KEY, id);
  } catch {
    // Ignore
  }
};

export const getLastFormState = (): CalculationInput | null => {
  try {
    const raw = localStorage.getItem(LAST_FORM_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch {
    // Ignore
  }
  return null;
};

export const saveLastFormState = (formData: CalculationInput): void => {
  try {
    localStorage.setItem(LAST_FORM_KEY, JSON.stringify(formData));
  } catch {
    // Ignore
  }
};
