import { CalculationResult } from '../types';

export const formatVND = (amount: number): string => {
  return new Intl.NumberFormat('vi-VN').format(Math.round(amount)) + ' đ';
};

export const generateBillShareText = (res: CalculationResult): string => {
  const dateStr = res.calculatedAt;
  const roomHeader = res.roomName ? `PHÒNG: ${res.roomName.toUpperCase()}` : 'HÓA ĐƠN TIỀN TRỌ';
  const monthHeader = res.monthYear ? `KỲ: ${res.monthYear}` : `NGÀY LẬP: ${dateStr}`;

  return `🧾 ${roomHeader}
📅 ${monthHeader}
---------------------------------
🏠 1. Tiền phòng: ${formatVND(res.roomRent)}
⚡ 2. Tiền điện: ${formatVND(res.electricityTotal)}
   • Chỉ số: ${res.newElectricity} - ${res.oldElectricity} = ${res.electricityUsed} kWh
   • Đơn giá: 3.500 đ/kWh
💧 3. Tiền nước: ${formatVND(res.waterTotal)}
   • Số người: ${res.occupants} người x 20.000 đ
🗑️ 4. Tiền rác: ${formatVND(res.garbageTotal)} (Cố định/phòng)
---------------------------------
💰 TỔNG CỘNG: ${formatVND(res.grandTotal)}
---------------------------------
Vui lòng thanh toán tiền trọ đúng hạn. Xin cảm ơn!`;
};
